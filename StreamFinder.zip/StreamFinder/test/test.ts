import { test } from 'node:test';
import * as streamingAvailability from "../src/index";

type TestFunction = (client: streamingAvailability.Client) => Promise<any>

const testMap = new Map<string, TestFunction>(
	[
		["getShow", testGetShow],
		["searchShows", testSearchShows],
	],
)

const apiKey =  process.env.API_KEY;
const isMock = !apiKey || process.env.USE_MOCK === "true";

const createMockShow = (id: string, title: string) => ({
	id: id,
	itemType: "show",
	showType: "movie",
	imdbId: "tt" + id,
	tmdbId: "tmdb" + id,
	title: title,
	overview: "Overview for " + title,
	originalTitle: title,
	genres: [{ id: "action", name: "Action" }],
	cast: ["Marlon Brando", "Al Pacino"],
	rating: 92,
	releaseYear: 1972,
	imageSet: {
		verticalPoster: { w240: "https://example.com/poster.jpg", w360: "https://example.com/poster.jpg", w480: "https://example.com/poster.jpg", w600: "https://example.com/poster.jpg", w720: "https://example.com/poster.jpg" },
		horizontalPoster: { w360: "https://example.com/hposter.jpg", w480: "https://example.com/hposter.jpg", w720: "https://example.com/hposter.jpg", w1080: "https://example.com/hposter.jpg", w1440: "https://example.com/hposter.jpg" },
		verticalBackdrop: { w240: "https://example.com/vbackdrop.jpg", w360: "https://example.com/vbackdrop.jpg", w480: "https://example.com/vbackdrop.jpg", w600: "https://example.com/vbackdrop.jpg", w720: "https://example.com/vbackdrop.jpg" },
		horizontalBackdrop: { w360: "https://example.com/backdrop.jpg", w480: "https://example.com/backdrop.jpg", w720: "https://example.com/backdrop.jpg", w1080: "https://example.com/backdrop.jpg", w1440: "https://example.com/backdrop.jpg" }
	},
	streamingOptions: {
		us: [{
			service: { id: "netflix", name: "Netflix", homePage: "https://netflix.com", themeColorCode: "#E50914" },
			type: "subscription",
			link: "https://netflix.com/watch"
		}]
	}
});

let mockFetch: typeof fetch | undefined = undefined;
if (isMock) {
	mockFetch = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
		const urlStr = input.toString();
		if (urlStr.includes('/shows/tt0068646') || urlStr.includes('/shows/show_1')) {
			return new Response(JSON.stringify(createMockShow("tt0068646", "The Godfather")), {
				status: 200,
				headers: { 'Content-Type': 'application/json' }
			});
		}

		if (urlStr.includes('/shows/search/filters')) {
			const hasCursor = urlStr.includes('cursor=');
			const shows = hasCursor 
				? [createMockShow("movie_page_2", "Page 2 Action Movie")] 
				: [createMockShow("movie_page_1", "Page 1 Action Movie")];

			return new Response(JSON.stringify({
				shows: shows,
				hasMore: !hasCursor,
				nextCursor: hasCursor ? undefined : "cursor_page_2"
			}), {
				status: 200,
				headers: { 'Content-Type': 'application/json' }
			});
		}

		if (urlStr.includes('/changes')) {
			const hasCursor = urlStr.includes('cursor=');
			return new Response(JSON.stringify({
				changes: [
					{
						changeType: "new",
						itemType: "show",
						showId: "show_1",
						timestamp: 1600000000
					}
				],
				shows: {
					"show_1": createMockShow("show_1", "New Movie Release")
				},
				hasMore: !hasCursor,
				nextCursor: hasCursor ? undefined : "changes_page_2"
			}), {
				status: 200,
				headers: { 'Content-Type': 'application/json' }
			});
		}

		return new Response(JSON.stringify({}), {
			status: 200,
			headers: { 'Content-Type': 'application/json' }
		});
	};
}

const client = new streamingAvailability.Client(new streamingAvailability.Configuration({
	apiKey: apiKey || "mock-api-key",
	fetchApi: mockFetch
}));

testMap.forEach((testFunction, name) => {
	test(name, () => {
		return testFunction(client)
	})
})

function testGetShow(client: streamingAvailability.Client): Promise<streamingAvailability.Show> {
	return client.showsApi.getShow({
		id: "tt0068646",
		country: "us",
	})
}

function testSearchShows(client: streamingAvailability.Client): Promise<streamingAvailability.SearchResult> {
	return client.showsApi.searchShowsByFilters({
		catalogs: ["netflix"],
		country: "us",
		genres: ["action"],
	})
}

test("searchShowsByFiltersWithAutoPaginationWith2Pages", async () => {
	const shows = client.showsApi.searchShowsByFiltersWithAutoPagination({
		catalogs: ["netflix"],
		country: "us",
		genres: ["action"],
		orderBy: "popularity_1year",
	}, 2)
	for await (const show of shows) {
		console.log(show.title);
	}
});

test("searchShowsByFiltersWithAutoPaginationWithEndlessPages", async () => {
	const shows = client.showsApi.searchShowsByFiltersWithAutoPagination({
		catalogs: ["netflix"],
		country: "us",
		genres: ["action"],
		orderBy: "popularity_alltime",
		showType: "movie",
		yearMax: 2021,
		yearMin: 2020

	}, 0)
	for await (const show of shows) {
		console.log(show.title);
	}
});

test("getChangesWithAutoPagination", async () => {
	const changes = client.changesApi.getChangesWithAutoPagination({
		country: "us",
		catalogs: ["netflix"],
		itemType: "show",
		changeType: "new",
	}, 2);
	for await (const change of changes) {
		console.log(change.show.title);
	}
});

