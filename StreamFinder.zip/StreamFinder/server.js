const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/bundle.min.js', express.static(path.join(__dirname, 'bundle.min.js')));

// Load TypeScript SDK client if available
let streamingAvailability = null;
let sdkClient = null;
try {
  streamingAvailability = require('./dist/index.js');
} catch (e) {
  console.warn('Could not load dist/index.js SDK:', e.message);
}

// Config state
const config = {
  tmdbApiKey: process.env.TMDB_API_KEY || '37d909951f4db42c0be79d6f27512b58',
  motnApiKey: process.env.STREAMING_AVAILABILITY_API_KEY || 'motn-key-v4-88FkawwqSCLfDH0nbCORLkV1BEpdXMF6',
  tmdbBase: 'https://api.tmdb.org/3',
  imageBase: 'https://image.tmdb.org/t/p'
};

function initSdk() {
  if (streamingAvailability && config.motnApiKey) {
    try {
      sdkClient = new streamingAvailability.Client(
        new streamingAvailability.Configuration({ apiKey: config.motnApiKey })
      );
    } catch (e) {
      console.warn('Failed to init SDK client:', e.message);
    }
  }
}
initSdk();

// Cache helper
const cache = new Map();
function getCache(key) {
  const item = cache.get(key);
  if (item && Date.now() - item.time < 300000) { // 5 min cache
    return item.data;
  }
  return null;
}
function setCache(key, data) {
  cache.set(key, { time: Date.now(), data });
}

// Helper TMDB Fetcher
async function fetchTMDB(endpoint, params = {}) {
  const searchParams = new URLSearchParams({
    api_key: config.tmdbApiKey,
    ...params
  });
  const url = `${config.tmdbBase}${endpoint}?${searchParams.toString()}`;
  const cacheKey = url;
  const cached = getCache(cacheKey);
  if (cached) return cached;

  const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`TMDB error ${res.status}: ${errorText}`);
  }
  const data = await res.json();
  setCache(cacheKey, data);
  return data;
}

// Map service slugs to TMDB provider IDs
const SERVICE_MAP = {
  netflix: 8,
  prime: 119,
  disney: 337,
  max: 1899,
  hbo: 1899,
  apple: 350,
  paramount: 531,
  hulu: 15,
  peacock: 386,
  pluto: 300
};

// Genre mapping (TMDB genre IDs)
const GENRE_MAP = {
  action: 28,
  adventure: 12,
  animation: 16,
  comedy: 35,
  crime: 80,
  documentary: 99,
  drama: 18,
  family: 10751,
  fantasy: 14,
  history: 36,
  horror: 27,
  music: 10402,
  mystery: 9648,
  romance: 10749,
  scifi: 878,
  science_fiction: 878,
  thriller: 53,
  war: 10752,
  western: 37
};

function formatMedia(item, mediaType = 'movie', badge = '') {
  const title = item.title || item.name || 'Untitled';
  const releaseDate = item.release_date || item.first_air_date || '';
  const year = releaseDate ? releaseDate.split('-')[0] : '';
  const rating = item.vote_average ? Number(item.vote_average.toFixed(1)) : 0;
  
  // Use backdrop if available, fallback to poster
  const backdrop = item.backdrop_path 
    ? `${config.imageBase}/w780${item.backdrop_path}` 
    : (item.poster_path ? `${config.imageBase}/w500${item.poster_path}` : 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=780&auto=format&fit=crop&q=80');

  const poster = item.poster_path 
    ? `${config.imageBase}/w500${item.poster_path}` 
    : backdrop;

  return {
    id: item.id,
    title,
    originalTitle: item.original_title || item.original_name || title,
    overview: item.overview || 'No overview available.',
    mediaType: item.media_type || mediaType,
    rating,
    voteCount: item.vote_count || 0,
    releaseYear: year,
    backdrop,
    poster,
    badge,
    popularity: item.popularity || 0,
    genreIds: item.genre_ids || []
  };
}

// 1. Featured Homepage Rows (matching Movie of the Night screenshot)
app.get('/api/shows/featured', async (req, res) => {
  const country = (req.query.country || 'US').toUpperCase();
  try {
    const [serialKiller, sports, comedySeries, topClassics, trending] = await Promise.all([
      // Serial Killer & Crime Movies
      fetchTMDB('/discover/movie', {
        with_genres: '80,53', // Crime, Thriller
        sort_by: 'popularity.desc',
        'vote_count.gte': '100',
        watch_region: country,
        page: 1
      }).catch(() => ({ results: [] })),

      // Most Popular Sport Movies
      fetchTMDB('/discover/movie', {
        with_keywords: '6075|9715|18035|207865', // sports, boxing, racing
        sort_by: 'popularity.desc',
        'vote_count.gte': '200',
        page: 1
      }).catch(async () => {
        return fetchTMDB('/search/movie', { query: 'Rocky' });
      }),

      // Quirky Comedy Series
      fetchTMDB('/discover/tv', {
        with_genres: '35', // Comedy
        sort_by: 'popularity.desc',
        'vote_count.gte': '80',
        page: 1
      }).catch(() => ({ results: [] })),

      // Top Rated Classics
      fetchTMDB('/movie/top_rated', {
        page: 1
      }).catch(() => ({ results: [] })),

      // Trending today
      fetchTMDB('/trending/all/day', {
        page: 1
      }).catch(() => ({ results: [] }))
    ]);

    // Format rows
    const responseData = {
      country,
      categories: [
        {
          id: 'serial-killer',
          title: 'Serial Killer Movies',
          items: (serialKiller.results || []).slice(0, 12).map((m, i) => 
            formatMedia(m, 'movie', i === 0 || i === 3 ? 'Recently Added' : '')
          )
        },
        {
          id: 'popular-sport',
          title: 'Most Popular Sport Movies',
          items: (sports.results || []).slice(0, 12).map((m, i) => 
            formatMedia(m, 'movie', i === 1 ? 'HD' : '')
          )
        },
        {
          id: 'quirky-comedy',
          title: 'Quirky Comedy Series',
          items: (comedySeries.results || []).slice(0, 12).map((m, i) => 
            formatMedia(m, 'tv', i === 2 ? 'New Season' : '')
          )
        },
        {
          id: 'top-rated',
          title: 'Top Rated Movies & Shows',
          items: (topClassics.results || []).slice(0, 12).map((m) => 
            formatMedia(m, 'movie')
          )
        },
        {
          id: 'trending-now',
          title: 'Trending Today Across All Platforms',
          items: (trending.results || []).slice(0, 12).map((m) => 
            formatMedia(m, m.media_type || 'movie')
          )
        }
      ]
    };

    res.json(responseData);
  } catch (err) {
    console.error('Error fetching featured:', err);
    res.status(500).json({ error: 'Failed to fetch featured shows', message: err.message });
  }
});

// 2. Discover & Filtering
app.get('/api/shows/discover', async (req, res) => {
  try {
    const {
      type = 'movie', // 'movie', 'tv', 'all'
      service,        // 'netflix', 'prime', etc.
      genre,          // genre slug or id
      country = 'US',
      rating = '0',
      page = '1',
      sortBy = 'popularity.desc'
    } = req.query;

    const params = {
      page,
      sort_by: sortBy,
      watch_region: country.toUpperCase()
    };

    if (rating && Number(rating) > 0) {
      params['vote_average.gte'] = rating;
      params['vote_count.gte'] = '50';
    }

    if (service && SERVICE_MAP[service.toLowerCase()]) {
      params.with_watch_providers = SERVICE_MAP[service.toLowerCase()];
    }

    if (genre) {
      const genreId = GENRE_MAP[genre.toLowerCase()] || genre;
      params.with_genres = genreId;
    }

    const endpoint = type === 'tv' ? '/discover/tv' : '/discover/movie';
    const data = await fetchTMDB(endpoint, params);

    const items = (data.results || []).map(item => formatMedia(item, type));

    res.json({
      page: data.page || 1,
      totalPages: Math.min(data.total_pages || 1, 100),
      totalResults: data.total_results || items.length,
      shows: items
    });
  } catch (err) {
    console.error('Error discovering:', err);
    res.status(500).json({ error: 'Failed to discover shows', message: err.message });
  }
});

// 3. Search
app.get('/api/shows/search', async (req, res) => {
  try {
    const { q, page = '1' } = req.query;
    if (!q || !q.trim()) {
      return res.json({ shows: [] });
    }

    const data = await fetchTMDB('/search/multi', {
      query: q.trim(),
      page
    });

    const items = (data.results || [])
      .filter(item => item.media_type === 'movie' || item.media_type === 'tv')
      .map(item => formatMedia(item, item.media_type));

    res.json({
      query: q,
      page: data.page || 1,
      totalPages: data.total_pages || 1,
      totalResults: data.total_results || items.length,
      shows: items
    });
  } catch (err) {
    console.error('Error searching:', err);
    res.status(500).json({ error: 'Search failed', message: err.message });
  }
});

// 4. Detailed Show & Streaming Options
app.get('/api/shows/:id', async (req, res) => {
  const { id } = req.params;
  const mediaType = req.query.type === 'tv' ? 'tv' : 'movie';
  const country = (req.query.country || 'US').toUpperCase();

  try {
    // Parallel fetch details, credits, videos, and watch providers
    const [details, credits, videos, providers] = await Promise.all([
      fetchTMDB(`/${mediaType}/${id}`),
      fetchTMDB(`/${mediaType}/${id}/credits`).catch(() => ({ cast: [], crew: [] })),
      fetchTMDB(`/${mediaType}/${id}/videos`).catch(() => ({ results: [] })),
      fetchTMDB(`/${mediaType}/${id}/watch/providers`).catch(() => ({ results: {} }))
    ]);

    // Parse streaming providers
    const countryProviders = providers.results?.[country] || providers.results?.['US'] || {};
    const streamOptions = [];

    // Subscription
    if (Array.isArray(countryProviders.flatrate)) {
      countryProviders.flatrate.forEach(p => {
        streamOptions.push({
          type: 'subscription',
          serviceName: p.provider_name,
          logo: `${config.imageBase}/w92${p.logo_path}`,
          link: countryProviders.link || `https://www.google.com/search?q=watch+${encodeURIComponent(details.title || details.name)}+on+${encodeURIComponent(p.provider_name)}`
        });
      });
    }

    // Rent
    const rentOptions = [];
    if (Array.isArray(countryProviders.rent)) {
      countryProviders.rent.forEach(p => {
        rentOptions.push({
          type: 'rent',
          serviceName: p.provider_name,
          logo: `${config.imageBase}/w92${p.logo_path}`,
          link: countryProviders.link || `https://www.google.com/search?q=rent+${encodeURIComponent(details.title || details.name)}+on+${encodeURIComponent(p.provider_name)}`
        });
      });
    }

    // Buy
    const buyOptions = [];
    if (Array.isArray(countryProviders.buy)) {
      countryProviders.buy.forEach(p => {
        buyOptions.push({
          type: 'buy',
          serviceName: p.provider_name,
          logo: `${config.imageBase}/w92${p.logo_path}`,
          link: countryProviders.link || `https://www.google.com/search?q=buy+${encodeURIComponent(details.title || details.name)}+on+${encodeURIComponent(p.provider_name)}`
        });
      });
    }

    // Trailer
    const trailer = (videos.results || []).find(v => v.type === 'Trailer' && v.site === 'YouTube')
      || (videos.results || [])[0];

    // Directors / Creators
    const directors = credits.crew ? credits.crew.filter(c => c.job === 'Director').map(c => c.name) : [];
    const cast = credits.cast ? credits.cast.slice(0, 8).map(c => ({
      name: c.name,
      character: c.character,
      profile: c.profile_path ? `${config.imageBase}/w185${c.profile_path}` : null
    })) : [];

    const formatted = formatMedia(details, mediaType);
    formatted.genres = (details.genres || []).map(g => g.name);
    formatted.runtime = details.runtime ? `${Math.floor(details.runtime / 60)}h ${details.runtime % 60}m` : (details.episode_run_time?.[0] ? `${details.episode_run_time[0]}m` : null);
    formatted.tagline = details.tagline || '';
    formatted.directors = directors;
    formatted.cast = cast;
    formatted.trailerUrl = trailer ? `https://www.youtube.com/watch?v=${trailer.key}` : null;
    formatted.trailerKey = trailer?.key || null;
    formatted.streaming = {
      country,
      webLink: countryProviders.link || null,
      subscription: streamOptions,
      rent: rentOptions,
      buy: buyOptions
    };

    res.json(formatted);
  } catch (err) {
    console.error('Error fetching show detail:', err);
    res.status(500).json({ error: 'Failed to fetch show details', message: err.message });
  }
});

// 5. SDK Demo / Tester Endpoint
app.get('/api/sdk-demo', async (req, res) => {
  if (!streamingAvailability) {
    return res.status(500).json({ error: 'SDK library not built or available.' });
  }

  try {
    // Demonstrate SDK initialization & model reflection
    const sdkInfo = {
      version: require('./package.json').version,
      hasClient: !!streamingAvailability.Client,
      hasShowsApi: !!streamingAvailability.ShowsApi,
      hasGenresApi: !!streamingAvailability.GenresApi,
      hasCountriesApi: !!streamingAvailability.CountriesApi,
      hasChangesApi: !!streamingAvailability.ChangesApi,
      status: 'Active & Compiled'
    };

    // If an active MOTN API key is configured and not default dummy, test live
    let liveResult = null;
    if (sdkClient && config.motnApiKey && !config.motnApiKey.includes('88FkawwqSCLfDH0nbCORLkV1BEpdXMF6')) {
      try {
        liveResult = await sdkClient.showsApi.getShow({ id: 'tt0068646', country: 'us' });
      } catch (e) {
        liveResult = { error: e.message };
      }
    }

    res.json({
      sdkInfo,
      activeKeyPrefix: config.motnApiKey ? config.motnApiKey.slice(0, 15) + '...' : 'Not Set',
      liveResult
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 6. Config endpoint to view/update keys
app.get('/api/config', (req, res) => {
  res.json({
    tmdbApiKey: config.tmdbApiKey ? `${config.tmdbApiKey.slice(0, 6)}...${config.tmdbApiKey.slice(-4)}` : 'Not Set',
    motnApiKey: config.motnApiKey ? `${config.motnApiKey.slice(0, 12)}...` : 'Not Set',
    hasTmdb: !!config.tmdbApiKey,
    hasMotn: !!config.motnApiKey
  });
});

app.post('/api/config', (req, res) => {
  const { tmdbApiKey, motnApiKey } = req.body;
  if (tmdbApiKey) config.tmdbApiKey = tmdbApiKey.trim();
  if (motnApiKey) {
    config.motnApiKey = motnApiKey.trim();
    initSdk();
  }
  cache.clear();
  res.json({ success: true, message: 'Configuration updated successfully!' });
});

// Fallback to index.html
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n======================================================`);
  console.log(`🎬 Movie of the Night (Local Host) is RUNNING!`);
  console.log(`🌐 Local URL: http://localhost:${PORT}`);
  console.log(`📦 TS Client SDK loaded and ready`);
  console.log(`======================================================\n`);
});
